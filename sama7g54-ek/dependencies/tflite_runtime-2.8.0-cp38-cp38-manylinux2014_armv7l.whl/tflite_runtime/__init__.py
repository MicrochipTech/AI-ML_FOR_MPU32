__version__ = '2.8.0'
__git_version__ = '0.6.0-122947-gf06f10ddd92'
